/** Automatically generated file. DO NOT MODIFY */
package com.commonsware.cwac.loaderex.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
/** Automatically generated file. DO NOT MODIFY */
package com.commonsware.cwac.loaderex;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}